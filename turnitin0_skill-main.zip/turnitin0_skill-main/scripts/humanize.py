#!/usr/bin/env python3
from _forward import forward

if __name__ == "__main__":
    forward("humanize.py")
